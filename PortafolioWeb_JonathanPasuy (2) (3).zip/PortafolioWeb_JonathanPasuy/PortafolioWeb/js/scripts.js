/* ==========================================
   PORTAFOLIO - Jonathan David Pasuy González
   scripts.js  |  jQuery + Bootstrap JS
   ========================================== */

$(document).ready(function () {

  /* ---- Navbar scroll effect ---- */
  $(window).on('scroll', function () {
    if ($(this).scrollTop() > 40) {
      $('#mainNav').addClass('scrolled');
    } else {
      $('#mainNav').removeClass('scrolled');
    }
  });

  /* ---- Video Modal: abrir con jQuery ---- */
  // Cada botón "Ver Video" lleva data-video (URL embed) y data-title
  $(document).on('click', '.btn-project', function () {
    var videoUrl  = $(this).data('video');
    var videoTitle = $(this).data('title');

    // Actualizar título del modal
    $('#videoModalLabel').html('<i class="fab fa-youtube me-2"></i>' + videoTitle);

    // Insertar la URL del iframe
    // Añadir autoplay=1 para que inicie automáticamente
    $('#videoFrame').attr('src', videoUrl + '?autoplay=1&rel=0');

    // Abrir el modal con Bootstrap JS
    var videoModal = new bootstrap.Modal(document.getElementById('videoModal'));
    videoModal.show();
  });

  /* ---- Limpiar iframe al cerrar modal (evita que el video siga sonando) ---- */
  $('#videoModal').on('hidden.bs.modal', function () {
    $('#videoFrame').attr('src', '');
  });

  /* ---- Animación de entrada para las skill-cards (Intersection Observer via jQuery) ---- */
  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          $(entry.target).addClass('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    $('.skill-card, .project-card, .stat-card').each(function () {
      $(this).css({ opacity: 0, transform: 'translateY(24px)', transition: 'opacity 0.5s ease, transform 0.5s ease' });
      observer.observe(this);
    });

    // Clase visible dispara la transición
    $('<style>.skill-card.visible, .project-card.visible, .stat-card.visible { opacity: 1 !important; transform: none !important; }</style>').appendTo('head');
  }

  /* ---- Smooth scroll para anchors internos ---- */
  $('a[href^="#"]').on('click', function (e) {
    var target = $(this.getAttribute('href'));
    if (target.length) {
      e.preventDefault();
      $('html, body').animate({ scrollTop: target.offset().top - 80 }, 500, 'swing');
    }
  });

});
